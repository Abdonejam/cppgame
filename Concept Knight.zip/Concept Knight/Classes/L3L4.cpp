#include "L3L4.h"
#include "Level4Scene.h"

USING_NS_CC;

Scene* Transition34::createScene()
{
    return Transition34::create();

}


// on "init" you need to initialize your instance
bool Transition34::init()
{
    //////////////////////////////
    // 1. super init first
    if (!Scene::init())
    {
        return false;
    }

    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    auto NextItem = MenuItemImage::create("Next_But.png", "Next_But.png", CC_CALLBACK_1(Transition34::NextLevel, this));
    NextItem->setPosition(Vec2(visibleSize.width / 2, 400 ));


    auto BGSplash = Sprite::create("BG7.png");
    BGSplash->setPosition(Vec2(visibleSize.width / 2, visibleSize.height / 2));
    BGSplash->setScale(1.3);
    this->addChild(BGSplash, -1);



    auto menu = Menu::create(NextItem, NULL);
    menu->setPosition(Vec2::ZERO);
    this->addChild(menu, 1);

    return true;
}

void Transition34::NextLevel(Ref* pSender)
{
    auto Level4 = Level4::create();
    Director::getInstance()->replaceScene(TransitionFade::create(0.5, Level4, Color3B(0, 255, 255)));
}
