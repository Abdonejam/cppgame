#include "Level4Scene.h"
#include "End.h"

USING_NS_CC;

Scene* Level4::createScene()
{
    auto scene = Scene::createWithPhysics();
    auto layer = Level4::create();
    layer->setPhyWorld(scene->getPhysicsWorld());
    return scene;
}

//Global variables needed 

int DirX4 = 0 ;
int DirY4 = 0 ;

bool key_condition = false ;
bool jump_condition4 = true;

cocos2d::Sprite* Knight4;
cocos2d::Sprite* Obj4;
cocos2d::Sprite* Hornet4;

// on "init" you need to initialize your instance
bool Level4::init() {
    
    auto scene = Scene::initWithPhysics();

        //add Physic Bodies
    auto physicsplayer = PhysicsBody::createBox(Size(65, 115), PhysicsMaterial(100.0f, 0.0f, 20.0f));
    physicsplayer->setDynamic(true);
    physicsplayer->setCollisionBitmask(1);
    physicsplayer->setContactTestBitmask(true);

    auto physicshornet = PhysicsBody::createBox(Size(65, 115), PhysicsMaterial(100.0f, 0.0f, 20.0f));
    physicshornet->setDynamic(true);
    physicshornet->setCollisionBitmask(1);
    physicshornet->setContactTestBitmask(true);

    auto physicsobj = PhysicsBody::createBox(Size(300, 250), PhysicsMaterial(1.0f, 0.0f, 20.0f));
    physicsobj->setDynamic(false);
    physicsobj->setCollisionBitmask(2);
    physicsobj->setContactTestBitmask(true);

     auto physicsfloor = PhysicsBody::createBox(Size(1080, 125), PhysicsMaterial(1.0f, 0.0f, 20.0f));
     physicsfloor->setDynamic(false);
     physicsfloor->setCollisionBitmask(3);
     physicsfloor->setContactTestBitmask(true);

    auto physicsseparate = PhysicsBody::createBox(Size(1080, 125), PhysicsMaterial(1.0f, 0.0f, 20.0f));
    physicsseparate->setDynamic(false);
    physicsseparate->setCollisionBitmask(3);
    physicsseparate->setContactTestBitmask(true);

    auto physicskey = PhysicsBody::createBox(Size(50, 50), PhysicsMaterial(1.0f, 0.0f, 20.0f));
    physicskey->setDynamic(false);
    physicsseparate->setCollisionBitmask(4);
    physicsseparate->setContactTestBitmask(true);

    auto physicsplatform = PhysicsBody::createBox(Size(650, 300), PhysicsMaterial(1.0f, 0.0f, 20.0f));
    physicsplatform->setDynamic(false);
    physicsplatform->setCollisionBitmask(3);
    physicsplatform->setContactTestBitmask(true);
    

     auto physicsfloorL = PhysicsBody::createBox(Size(150, 1080), PhysicsMaterial(1.0f, 0.0f, 20.0f));
     physicsfloorL->setDynamic(false);


     auto physicsfloorR = PhysicsBody::createBox(Size(150, 1080), PhysicsMaterial(1.0f, 0.0f, 20.0f));
     physicsfloorR->setDynamic(false);

     auto physicsroof = PhysicsBody::createBox(Size(1080, 300), PhysicsMaterial(1.0f, 0.0f, 20.0f));
     physicsroof->setDynamic(false);


    //collision detect listener
    auto contactListener = EventListenerPhysicsContact::create();
    contactListener->onContactBegin = CC_CALLBACK_1(Level4::ContactBegin, this);
    this->_eventDispatcher->addEventListenerWithSceneGraphPriority(contactListener, this);

    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();
    
    //Display Guide Text
    auto Level_Guide = Label::createWithTTF("Level4", "fonts/OB.ttf", 48);
    Level_Guide->setPosition(Vec2(visibleSize.width / 2, 650));
    this->addChild(Level_Guide);

    // add "Player Sprite" splash screen"
    ::Knight4= Sprite::create("Knight.png");
    ::Knight4->setPosition(Vec2(200, 50));
    ::Knight4->setScale(0.3);
    this->addChild(Knight4);
    Knight4->addComponent(physicsplayer);

    ::Hornet4 = Sprite::create("Hornet.png");
    ::Hornet4->setPosition(Vec2(200, 430));
    ::Hornet4->setScale(0.3);
    this->addChild(Hornet4);
    ::Hornet4->addComponent(physicshornet);

    ::Obj4 = Sprite::create("flag.png");
    ::Obj4->setPosition(Vec2(1000, 50));
    ::Obj4->setScale(0.5);
    this->addChild(Obj4);
    ::Obj4->addComponent(physicsobj);

    auto Seperator = Sprite::create("floor.png");
    Seperator->setPosition(Vec2(visibleSize.width / 2, visibleSize.height / 2));
    this->addChild(Seperator);
    Seperator->addComponent(physicsseparate);
    
    auto Key = Sprite::create("nail.png");
    Key->setPosition(Vec2(900, 580));
    Key->setScale(0.4);
    this->addChild(Key);
    Key->addComponent(physicskey);

    auto Platform = Sprite::create("LPath.png");
    Platform->setPosition(Vec2(700, 450));
    Platform->setScale(0.3);
    this->addChild(Platform);
    Platform->addComponent(physicsplatform);
 
    //Level background
    auto BGSplash = Sprite::create("BG7.png");
    BGSplash->setPosition(Vec2(visibleSize.width/2, visibleSize.height/2));
    BGSplash->setScale(1.3);
    this->addChild(BGSplash, -2);


    // add Screen Boundaries
    auto Floor = Sprite::create("floor.png");
    Floor->setPosition(Vec2(visibleSize.width / 2, -30));
    this->addChild(Floor);
    Floor->addComponent(physicsfloor);

    auto Roof = Sprite::create("floor.png");
    Roof->setPosition(Vec2(visibleSize.width / 2, 1030));
    this->addChild(Roof);
    Roof->addComponent(physicsroof);

    auto Box_L= Sprite::create("floor.png");
    Box_L->setPosition(Vec2(-35, 180));
    Box_L->setRotation(90);
    this->addChild(Box_L);
    Box_L->addComponent(physicsfloorL);

    auto Box_R = Sprite::create("floor.png");
    Box_R->setPosition(Vec2(1115, 180));
    Box_R->setRotation(90);
    this->addChild(Box_R);
    Box_R->addComponent(physicsfloorR);

    ///////////////////////////

    //Action Sequence to Move Pillar
  //  auto Move_Ver = MoveBy::create(1, Vec2(0, 125));
   // auto RMove_Ver = MoveBy::create(1, Vec2(0, -125));
   // auto Pillar_Mov = Sequence::create(Move_Ver, RMove_Ver, nullptr);
  //  auto repeat = RepeatForever::create(Pillar_Mov);
  ///  Pillar->runAction(repeat);
   


    //Keyboard listener event
    auto keyboardListener = EventListenerKeyboard::create();

    keyboardListener->onKeyPressed = [=](EventKeyboard::KeyCode keyCode, Event* event)
{

    auto action = JumpBy::create(0.5, Point (0, 150), 100, 1);
    auto actionH = JumpBy::create(0.5, Point(0, 150), 100, 1);

    switch (keyCode)
    {
    case EventKeyboard::KeyCode::KEY_W:
    case EventKeyboard::KeyCode::KEY_UP_ARROW:
        if (jump_condition4 == true) {

            ::Knight4->runAction(action);
            ::Hornet4->runAction(actionH);
            jump_condition4 = false;
        }
        break;
    case EventKeyboard::KeyCode::KEY_A:
    case EventKeyboard::KeyCode::KEY_LEFT_ARROW:

        ::Knight4->setTexture("RKnight.png");
        ::Hornet4->setTexture("RHornet.png");
        DirX4 -= 4.0f;
        break;
    case EventKeyboard::KeyCode::KEY_S:
    case EventKeyboard::KeyCode::KEY_DOWN_ARROW:
        DirY4 -= 4.0f;
        break;
    case EventKeyboard::KeyCode::KEY_D:
    case EventKeyboard::KeyCode::KEY_RIGHT_ARROW:
        ::Knight4->setTexture("Knight.png");
        ::Hornet4->setTexture("Hornet.png");
        DirX4 += 4.0f;
        break;
    }
};
    //Opposite movement to stop character from gliding
    keyboardListener->onKeyReleased = [=](EventKeyboard::KeyCode keyCode, Event* event)
{
    auto action2 = MoveBy::create(0.35, Vec2(0, -50));
    auto actionH2 = MoveBy::create(0.35, Vec2(0, -50));

    switch (keyCode)
    {
    case EventKeyboard::KeyCode::KEY_W:
    case EventKeyboard::KeyCode::KEY_UP_ARROW:
        if (jump_condition4 == true) {

            ::Knight4->runAction(action2);
            ::Hornet4->runAction(actionH2);
            jump_condition4 = false;
        }
        break;
    case EventKeyboard::KeyCode::KEY_A:
    case EventKeyboard::KeyCode::KEY_LEFT_ARROW:
        DirX4 += 4.0f;
        break;
    case EventKeyboard::KeyCode::KEY_S:
    case EventKeyboard::KeyCode::KEY_DOWN_ARROW:
        DirY4 += 4.0f;
        break;
    case EventKeyboard::KeyCode::KEY_D:
    case EventKeyboard::KeyCode::KEY_RIGHT_ARROW:
        DirX4 -= 4.0f;
        break;
    }
};

this->_eventDispatcher->addEventListenerWithSceneGraphPriority(keyboardListener, this);

//call on update function 
this->scheduleUpdate();

return true;
}


//every frame this function works
void Level4::update(float dt) {

    float newPosX = ::Knight4->getPositionX() + (DirX4);
    float newPosY = ::Knight4->getPositionY() + (DirY4);

    float newHPosX = ::Hornet4->getPositionX() + (DirX4);
    float newHPosY = ::Hornet4->getPositionY() + (DirY4);
    
    ::Knight4->setPosition(newPosX, newPosY);
    ::Knight4->setRotation(0);

    ::Hornet4->setPosition(newHPosX, newHPosY);
    ::Hornet4->setRotation(0);
}

//check for player and objectif colliding
bool Level4::ContactBegin(cocos2d::PhysicsContact& contact) {

    PhysicsBody* a = contact.getShapeA()->getBody();
    PhysicsBody* b = contact.getShapeB()->getBody();


    if ((1 == a->getCollisionBitmask() && 3 == b->getCollisionBitmask()) || 3 == a->getCollisionBitmask() && 1 == b->getCollisionBitmask())
    {
        jump_condition4 = true;
    }

    if ((1 == a->getCollisionBitmask() && 4 == b->getCollisionBitmask()) || 3 == a->getCollisionBitmask() && 4 == b->getCollisionBitmask())
    {
        key_condition = true;
    }

    if ((1 == a->getCollisionBitmask() && 2 == b->getCollisionBitmask()) || 2 == a->getCollisionBitmask() && 1 == b->getCollisionBitmask()) 
    {
        if (key_condition == true) {
            auto End = Endclass::create();
            Director::getInstance()->replaceScene(TransitionFade::create(0.5, End, Color3B(0, 255, 255)));
        }
    }

    return true;
}
