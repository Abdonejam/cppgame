

#include "HelloWorldScene.h"
#include "Level1Scene.h"

USING_NS_CC;

Scene* HelloWorld::createScene()
{
    return HelloWorld::create();

}


// on "init" you need to initialize your instance
bool HelloWorld::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !Scene::init() )
    {
        return false;
    }

      auto visibleSize = Director::getInstance()->getVisibleSize();
      Vec2 origin = Director::getInstance()->getVisibleOrigin();

      auto closeItem = MenuItemImage::create("Exit_But.png", "Exit_But.png",CC_CALLBACK_1(HelloWorld::menuCloseCallback, this));
      closeItem->setPosition(Vec2(visibleSize.width / 2, 220));
 

      auto PlayItem = MenuItemImage::create("Start_But.png", "Start_But.png", CC_CALLBACK_1(HelloWorld::Play, this));
      PlayItem->setPosition(Vec2(visibleSize.width / 2, 350));

      // add "XXXX" splash screen"
      auto SplashCard = Sprite::create("SplashCard.png");

      // position the sprite on the center of the screen
      SplashCard->setPosition(Vec2(visibleSize.width / 2, 550));

      // add the sprite as a child to this layer
      this->addChild(SplashCard, 0);

      auto BGSplash = Sprite::create("BG3.jpg");
      BGSplash->setPosition(Vec2(visibleSize.width / 2, visibleSize.height / 2));
      BGSplash->setScale(1.15);
      this->addChild(BGSplash, -1);



      auto menu = Menu::create(closeItem, PlayItem, NULL);
      menu->setPosition(Vec2::ZERO);
      this->addChild(menu, 1);

    return true;
}


void HelloWorld::menuCloseCallback(Ref* pSender)
{
    //Close the cocos2d-x game scene and quit the application
    Director::getInstance()->end();
}

void HelloWorld::Play(Ref* pSender)
{
    auto Lv1 = Level1::create();
    Director::getInstance()->replaceScene(TransitionFade::create(0.5, Lv1, Color3B(0, 255, 255)));
}
