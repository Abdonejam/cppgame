#include "Level3Scene.h"
#include "L2L3.h"

USING_NS_CC;

Scene* Transition23::createScene()
{
    return Transition23::create();

}


// on "init" you need to initialize your instance
bool Transition23::init()
{
    //////////////////////////////
    // 1. super init first
    if (!Scene::init())
    {
        return false;
    }

    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    auto NextItem = MenuItemImage::create("Next_But.png", "Next_But.png", CC_CALLBACK_1(Transition23::NextLevel, this));
    NextItem->setPosition(Vec2(visibleSize.width / 2, 400 ));


    auto BGSplash = Sprite::create("BG1.jpg");
    BGSplash->setPosition(Vec2(visibleSize.width / 2, visibleSize.height / 2));
    BGSplash->setScale(1.15);
    this->addChild(BGSplash, -1);



    auto menu = Menu::create(NextItem, NULL);
    menu->setPosition(Vec2::ZERO);
    this->addChild(menu, 1);

    return true;
}

void Transition23::NextLevel(Ref* pSender)
{
    auto Level3 = Level3::create();
    Director::getInstance()->replaceScene(TransitionFade::create(0.5, Level3, Color3B(0, 255, 255)));
}
