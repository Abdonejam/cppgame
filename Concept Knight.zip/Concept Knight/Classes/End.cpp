#include "End.h"

USING_NS_CC;

Scene* Endclass::createScene()
{
    return Endclass::create();

}


// on "init" you need to initialize your instance
bool Endclass::init()
{
    //////////////////////////////
    // 1. super init first
    if (!Scene::init())
    {
        return false;
    }

    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    auto NextItem = MenuItemImage::create("Exit_But.png", "Next_But.png", CC_CALLBACK_1(Endclass::EndGame, this));
    NextItem->setPosition(Vec2(visibleSize.width /2 , visibleSize.height / 2));


    auto BGSplash = Sprite::create("Gameend.png");
    BGSplash->setPosition(Vec2(visibleSize.width / 2, visibleSize.height / 2));
    BGSplash->setScale(1);
    this->addChild(BGSplash, -1);



    auto menu = Menu::create(NextItem, NULL);
    menu->setPosition(Vec2::ZERO);
    this->addChild(menu, 1);

    return true;
}

void Endclass::EndGame(Ref* pSender)
{
    Director::getInstance()->end();
}
