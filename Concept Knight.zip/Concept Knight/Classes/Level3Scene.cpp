
#include "Level3Scene.h"
#include "L3L4.h"


USING_NS_CC;

Scene* Level3::createScene()
{
    auto scene = Scene::createWithPhysics();
    auto layer = Level3::create();
    layer->setPhyWorld(scene->getPhysicsWorld());
    return scene;
}

//Global variables needed 

int DirX3 = 0 ;
int DirY3 = 0 ;

bool jump_condition3 = true;

cocos2d::Sprite* Knight3;
cocos2d::Sprite* Obj3;

// on "init" you need to initialize your instance
bool Level3::init() {
    
    auto scene = Scene::initWithPhysics();

        //add Physic Bodies
    auto physicsplayer = PhysicsBody::createBox(Size(65, 115), PhysicsMaterial(100.0f, 0.0f, 20.0f));
    physicsplayer->setDynamic(true);
    physicsplayer->setCollisionBitmask(1);
    physicsplayer->setContactTestBitmask(true);

    auto physicsobj = PhysicsBody::createBox(Size(300, 250), PhysicsMaterial(1.0f, 0.0f, 20.0f));
    physicsobj->setDynamic(false);
    physicsobj->setCollisionBitmask(2);
    physicsobj->setContactTestBitmask(true);

     auto physicsfloor = PhysicsBody::createBox(Size(1080, 125), PhysicsMaterial(1.0f, 0.0f, 20.0f));
     physicsfloor->setDynamic(false);
     physicsfloor->setCollisionBitmask(3);
     physicsfloor->setContactTestBitmask(true);

     auto physicsfloorL = PhysicsBody::createBox(Size(150, 1080), PhysicsMaterial(1.0f, 0.0f, 20.0f));
     physicsfloorL->setDynamic(false);

     auto physicsfloorR = PhysicsBody::createBox(Size(150, 1080), PhysicsMaterial(1.0f, 0.0f, 20.0f));
     physicsfloorR->setDynamic(false);

     auto physicsroof = PhysicsBody::createBox(Size(1080, 300), PhysicsMaterial(1.0f, 0.0f, 20.0f));
     physicsroof->setDynamic(false);

     auto physicspillar = PhysicsBody::createBox(Size(300, 700), PhysicsMaterial(1.0f, 0.0f, 10.0f));
     physicspillar->setDynamic(false);
     physicspillar->setCollisionBitmask(4);
     physicspillar->setContactTestBitmask(true);

     auto physicspillar2 = PhysicsBody::createBox(Size(700, 300), PhysicsMaterial(1.0f, 0.0f, 10.0f));
     physicspillar2->setDynamic(false);
     physicspillar2->setCollisionBitmask(4);
     physicspillar2->setContactTestBitmask(true);

     auto physicspillar3 = PhysicsBody::createBox(Size(300, 700), PhysicsMaterial(1.0f, 0.0f, 10.0f));
     physicspillar3->setDynamic(false);
     physicspillar3->setCollisionBitmask(4);
     physicspillar3->setContactTestBitmask(true);

     auto physicsPlatform = PhysicsBody::createBox(Size(500, 300), PhysicsMaterial(1.0f, 0.0f, 20.0f));
     physicsPlatform->setDynamic(false);
     physicsPlatform->setCollisionBitmask(4);
     physicsPlatform->setContactTestBitmask(true);

     auto physicsPlatformObj = PhysicsBody::createBox(Size(500, 300), PhysicsMaterial(1.0f, 0.0f, 20.0f));
     physicsPlatformObj->setDynamic(false);


    //collision detect listener
    auto contactListener = EventListenerPhysicsContact::create();
    contactListener->onContactBegin = CC_CALLBACK_1(Level3::ContactBegin, this);
    this->_eventDispatcher->addEventListenerWithSceneGraphPriority(contactListener, this);

    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();
    
    //Display Guide Text
    auto Level_Guide = Label::createWithTTF("Level3", "fonts/OB.ttf", 48);
    Level_Guide->setPosition(Vec2(visibleSize.width / 2, 620));
    this->addChild(Level_Guide);

    // add "Player Sprite" splash screen"
    ::Knight3= Sprite::create("Knight.png");
    ::Knight3->setPosition(Vec2(200, 180));
    ::Knight3->setScale(0.3);
    this->addChild(Knight3);
    Knight3->addComponent(physicsplayer);

    ::Obj3 = Sprite::create("flag.png");
    ::Obj3->setPosition(Vec2(1000, 600));
    ::Obj3->setScale(0.5);
    this->addChild(Obj3);
    ::Obj3->addComponent(physicsobj);

    auto Platform = Sprite::create("LPath.png");
    Platform->setPosition(Vec2(100, 50));
    Platform->setScale(0.5);
    this->addChild(Platform);
    Platform->addComponent(physicsPlatform);

    auto Platform_Obj = Sprite::create("LPath.png");
    Platform_Obj->setPosition(Vec2(1000, 480));
    Platform_Obj->setScale(0.5);
    this->addChild(Platform_Obj);
    Platform_Obj->addComponent(physicsPlatformObj);
 
    //Level background
    auto BGSplash = Sprite::create("BG1.jpg");
    BGSplash->setPosition(Vec2(visibleSize.width/2, visibleSize.height/2));
    BGSplash->setScale(1.15);
    this->addChild(BGSplash, -2);


    // add Screen Boundaries
    auto Floor = Sprite::create("floor.png");
    Floor->setPosition(Vec2(visibleSize.width / 2, -30));
    this->addChild(Floor);
    Floor->addComponent(physicsfloor);

    auto Roof = Sprite::create("floor.png");
    Roof->setPosition(Vec2(visibleSize.width / 2, 1030));
    this->addChild(Roof);
    Roof->addComponent(physicsroof);

    auto Box_L= Sprite::create("floor.png");
    Box_L->setPosition(Vec2(-35, 180));
    Box_L->setRotation(90);
    this->addChild(Box_L);
    Box_L->addComponent(physicsfloorL);

    auto Box_R = Sprite::create("floor.png");
    Box_R->setPosition(Vec2(1115, 180));
    Box_R->setRotation(90);
    this->addChild(Box_R);
    Box_R->addComponent(physicsfloorR);

    ///////////////////////////

   

    //Moving Pillar
    auto Pillar = Sprite::create("LPath.png");
    Pillar->setPosition(Vec2(320, 125));
    Pillar->setScale(0.3);
    Pillar->setRotation(90);
    this->addChild(Pillar);
    Pillar->addComponent(physicspillar);

    auto Pillar2 = Sprite::create("LPath.png");
    Pillar2->setPosition(Vec2(520, 250));
    Pillar2->setScale(0.3);
    this->addChild(Pillar2);
    Pillar2->addComponent(physicspillar2);

    auto Pillar3 = Sprite::create("LPath.png");
    Pillar3->setPosition(Vec2(800, 300));
    Pillar3->setScale(0.3);
    Pillar3->setRotation(90);
    this->addChild(Pillar3);
    Pillar3->addComponent(physicspillar3);

    //Action Sequence to Move Pillar
    auto Move_Ver = MoveBy::create(1, Vec2(0, 125));
    auto RMove_Ver = MoveBy::create(1, Vec2(0, -125));
    auto Pillar_Mov = Sequence::create(Move_Ver, RMove_Ver, nullptr);
    auto repeat = RepeatForever::create(Pillar_Mov);
    Pillar->runAction(repeat);
    

    auto Move2_Ver = MoveBy::create(1.5, Vec2(170, 0));
    auto RMove2_Ver = MoveBy::create(1.5, Vec2(-170, 0));
    auto Pillar2_Mov = Sequence::create(Move2_Ver, RMove2_Ver, nullptr);
    auto repeat2 = RepeatForever::create(Pillar2_Mov);
    Pillar2->runAction(repeat2);

    auto Move3_Ver = MoveBy::create(1, Vec2(0,200));
    auto RMove3_Ver = MoveBy::create(1, Vec2(0, -200));
    auto Pillar3_Mov = Sequence::create(Move3_Ver, RMove3_Ver, nullptr);
    auto repeat3 = RepeatForever::create(Pillar3_Mov);
    Pillar3->runAction(repeat3);


    //Keyboard listener event
    auto keyboardListener = EventListenerKeyboard::create();

    keyboardListener->onKeyPressed = [=](EventKeyboard::KeyCode keyCode, Event* event)
{

    auto action = JumpBy::create(0.5, Point (0, 150), 150, 1);

    switch (keyCode)
    {
    case EventKeyboard::KeyCode::KEY_W:
    case EventKeyboard::KeyCode::KEY_UP_ARROW:
        if (::jump_condition3 == true) {
            ::Knight3->runAction(action);
            ::jump_condition3 = false;
        }

        break;
    case EventKeyboard::KeyCode::KEY_A:
    case EventKeyboard::KeyCode::KEY_LEFT_ARROW:

        ::Knight3->setTexture("RKnight.png");
        DirX3 -= 4.0f;
        break;
    case EventKeyboard::KeyCode::KEY_S:
    case EventKeyboard::KeyCode::KEY_DOWN_ARROW:
        DirY3 -= 4.0f;
        break;
    case EventKeyboard::KeyCode::KEY_D:
    case EventKeyboard::KeyCode::KEY_RIGHT_ARROW:
        ::Knight3->setTexture("Knight.png");
        DirX3 += 4.0f;
        break;
    }
};
    //Opposite movement to stop character from gliding
    keyboardListener->onKeyReleased = [=](EventKeyboard::KeyCode keyCode, Event* event)
{
    auto action2 = MoveBy::create(0.45, Vec2(0, -50));
    switch (keyCode)
    {
    case EventKeyboard::KeyCode::KEY_W:
    case EventKeyboard::KeyCode::KEY_UP_ARROW:
        if (::jump_condition3 == true) {
            ::Knight3->runAction(action2);
            ::jump_condition3 = false;
        }
        break;
    case EventKeyboard::KeyCode::KEY_A:
    case EventKeyboard::KeyCode::KEY_LEFT_ARROW:
        DirX3 += 4.0f;
        break;
    case EventKeyboard::KeyCode::KEY_S:
    case EventKeyboard::KeyCode::KEY_DOWN_ARROW:
        DirY3 += 4.0f;
        break;
    case EventKeyboard::KeyCode::KEY_D:
    case EventKeyboard::KeyCode::KEY_RIGHT_ARROW:
        DirX3 -= 4.0f;
        break;
    }
};

this->_eventDispatcher->addEventListenerWithSceneGraphPriority(keyboardListener, this);

//call on update function 
this->scheduleUpdate();

return true;
}


//every frame this function works
void Level3::update(float dt) {

    float newPosX = ::Knight3->getPositionX() + (DirX3);
    float newPosY = ::Knight3->getPositionY() + (DirY3);

    ::Knight3->setPosition(newPosX, newPosY);
    ::Knight3->setRotation(0);
}

//check for player and objectif colliding
bool Level3::ContactBegin(cocos2d::PhysicsContact& contact) {

    PhysicsBody* a = contact.getShapeA()->getBody();
    PhysicsBody* b = contact.getShapeB()->getBody();



    if ((1 == a->getCollisionBitmask() && 2 == b->getCollisionBitmask()) || 2 == a->getCollisionBitmask() && 1 == b->getCollisionBitmask()) 
    {
        auto Next34 = Transition34::create();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Next34, Color3B(0, 255, 255)));
    }

    if ((1 == a->getCollisionBitmask() && 3 == b->getCollisionBitmask()) || 3 == a->getCollisionBitmask() && 1 == b->getCollisionBitmask())
    {
        auto Restart = Level3::create();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Restart, Color3B(0, 255, 255)));
    }

    if ((1 == a->getCollisionBitmask() && 4 == b->getCollisionBitmask()) || 4 == a->getCollisionBitmask() && 1 == b->getCollisionBitmask())
    {
        ::jump_condition3 = true;
    }
    return true;
}
