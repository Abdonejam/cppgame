#include "L1L2.h"
#include "Level2Scene.h"

USING_NS_CC;

Scene* Transition12::createScene()
{
    return Transition12::create();

}


// on "init" you need to initialize your instance
bool Transition12::init()
{
    //////////////////////////////
    // 1. super init first
    if (!Scene::init())
    {
        return false;
    }

    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    auto NextItem = MenuItemImage::create("Next_But.png", "Next_But.png", CC_CALLBACK_1(Transition12::NextLevel, this));
    NextItem->setPosition(Vec2(visibleSize.width / 2, 400 ));


    auto BGSplash = Sprite::create("BG5.png");
    BGSplash->setPosition(Vec2(visibleSize.width / 2, visibleSize.height / 2));
    BGSplash->setScale(1.15);
    this->addChild(BGSplash, -1);



    auto menu = Menu::create(NextItem, NULL);
    menu->setPosition(Vec2::ZERO);
    this->addChild(menu, 1);

    return true;
}

void Transition12::NextLevel(Ref* pSender)
{
    auto Level2 = Level2::create();
    Director::getInstance()->replaceScene(TransitionFade::create(0.5, Level2, Color3B(0, 255, 255)));
}
