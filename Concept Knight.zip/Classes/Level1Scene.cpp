
#include "Level1Scene.h"
#include "L1L2.h"


USING_NS_CC;

Scene* Level1::createScene()
{
    auto scene = Scene::createWithPhysics();
    auto layer = Level1::create();
    layer->setPhyWorld(scene->getPhysicsWorld());
    return scene;
}

//Global variables needed 

int DirX = 0 ;
int DirY = 0 ;

bool jump_condition = true;

cocos2d::Sprite* Knight;
cocos2d::Sprite* Obj;

// on "init" you need to initialize your instance
bool Level1::init() {
    
    auto scene = Scene::initWithPhysics();
        //add Physic Bodies
    auto physicsplayer = PhysicsBody::createBox(Size(65, 115), PhysicsMaterial(100.0f, 0.0f, 20.0f));
    physicsplayer->setDynamic(true);

    auto physicsobj = PhysicsBody::createBox(Size(300, 300), PhysicsMaterial(1.0f, 0.0f, 20.0f));
    physicsobj->setDynamic(false);

     auto physicsfloor = PhysicsBody::createBox(Size(1080, 125), PhysicsMaterial(1.0f, 0.0f, 20.0f));
     physicsfloor->setDynamic(false);

     auto physicsfloorL = PhysicsBody::createBox(Size(150, 1080), PhysicsMaterial(1.0f, 0.0f, 20.0f));
     physicsfloorL->setDynamic(false);

     auto physicsfloorR = PhysicsBody::createBox(Size(150, 1080), PhysicsMaterial(1.0f, 0.0f, 20.0f));
     physicsfloorR->setDynamic(false);

     auto physicspillar = PhysicsBody::createBox(Size(300, 650), PhysicsMaterial(1.0f, 0.0f, 10.0f));
     physicspillar->setDynamic(false);

     auto physicsroof = PhysicsBody::createBox(Size(1080, 300), PhysicsMaterial(1.0f, 0.0f, 20.0f));
     physicsroof->setDynamic(false);


    //collision detect listener
    auto contactListener = EventListenerPhysicsContact::create();
    contactListener->onContactBegin = CC_CALLBACK_1(Level1::ContactBegin, this);
    this->_eventDispatcher->addEventListenerWithSceneGraphPriority(contactListener, this);

    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();
    
    //Display Guide Text
    auto Walk_Guide = Label::createWithTTF("Use Arrows/WASD to Move \n You can Double Jump", "fonts/OB.ttf", 32);
    Walk_Guide->setPosition(Vec2(visibleSize.width / 2, visibleSize.height / 2));
    this->addChild(Walk_Guide);

    auto Level_Guide = Label::createWithTTF("Level1", "fonts/OB.ttf", 48);
    Level_Guide->setPosition(Vec2(visibleSize.width / 2, 620));
    this->addChild(Level_Guide);

    // add "Player Sprite" splash screen"
    ::Knight= Sprite::create("Knight.png");
    ::Knight->setPosition(Vec2(200, 125));
    ::Knight->setScale(0.3);
    this->addChild(Knight);
    Knight->addComponent(physicsplayer);
    physicsplayer->setCollisionBitmask(1);
    physicsplayer->setContactTestBitmask(true);
 
    //Level background
    auto BGSplash = Sprite::create("BG3.jpg");
    BGSplash->setPosition(Vec2(visibleSize.width/2, visibleSize.height/2));
    BGSplash->setScale(1.15);
    this->addChild(BGSplash, -2);


    // add Screen Boundaries
    auto Floor = Sprite::create("floor.png");
    Floor->setPosition(Vec2(visibleSize.width / 2, 0));
    this->addChild(Floor);
    Floor->addComponent(physicsfloor);

    auto Roof = Sprite::create("floor.png");
    Roof->setPosition(Vec2(visibleSize.width / 2, 1080));
    this->addChild(Roof);
    Roof->addComponent(physicsroof);

    auto Box_L= Sprite::create("floor.png");
    Box_L->setPosition(Vec2(-30, 180));
    Box_L->setRotation(90);
    this->addChild(Box_L);
    Box_L->addComponent(physicsfloorL);

    auto Box_R = Sprite::create("floor.png");
    Box_R->setPosition(Vec2(1110, 180));
    Box_R->setRotation(90);
    this->addChild(Box_R);
    Box_R->addComponent(physicsfloorR);

    //Flag to clear the level

    ::Obj = Sprite::create("flag.png");
    ::Obj->setPosition(Vec2(1000, 100));
    ::Obj->setScale(0.5);
    this->addChild(Obj);
    ::Obj->addComponent(physicsobj);
    physicsobj->setCollisionBitmask(2);
    physicsobj->setContactTestBitmask(true);

    //Moving Pillar
    auto Pillar = Sprite::create("LPath.png");
    Pillar->setPosition(Vec2(450, 130));
    Pillar->setScale(0.3);
    Pillar->setRotation(90);
    this->addChild(Pillar);
    Pillar->addComponent(physicspillar);

    //Action Sequence to Move Pillar
    auto Move_Ver = MoveBy::create(1, Vec2(0, 125));
    auto RMove_Ver = MoveBy::create(1, Vec2(0, -125));
    auto Pillar_Mov = Sequence::create(Move_Ver, RMove_Ver, nullptr);
    auto repeat = RepeatForever::create(Pillar_Mov);
    Pillar->runAction(repeat);

    //Keyboard listener event
    auto keyboardListener = EventListenerKeyboard::create();

    keyboardListener->onKeyPressed = [=](EventKeyboard::KeyCode keyCode, Event* event)
{

    auto action = JumpBy::create(0.5, Point
    (0, ::Knight->getPositionY() + 150), 150, 1);

    switch (keyCode)
    {
    case EventKeyboard::KeyCode::KEY_W:
    case EventKeyboard::KeyCode::KEY_UP_ARROW:
        if (::jump_condition == true) {
            ::Knight->runAction(action);
            ::jump_condition = false;
        }

        break;
    case EventKeyboard::KeyCode::KEY_A:
    case EventKeyboard::KeyCode::KEY_LEFT_ARROW:

        ::Knight->setTexture("RKnight.png");
        DirX -= 4.0f;
        break;
    case EventKeyboard::KeyCode::KEY_S:
    case EventKeyboard::KeyCode::KEY_DOWN_ARROW:
        DirY -= 4.0f;
        break;
    case EventKeyboard::KeyCode::KEY_D:
    case EventKeyboard::KeyCode::KEY_RIGHT_ARROW:
        ::Knight->setTexture("Knight.png");
        DirX += 4.0f;
        break;
    }
};
    //Opposite movement to stop character from gliding
    keyboardListener->onKeyReleased = [=](EventKeyboard::KeyCode keyCode, Event* event)
{
    auto action2 = MoveBy::create(0.35, Vec2(0, -150));
    switch (keyCode)
    {
    case EventKeyboard::KeyCode::KEY_W:
    case EventKeyboard::KeyCode::KEY_UP_ARROW:

        if (::jump_condition == true) {
            ::Knight->runAction(action2);
            ::jump_condition = false;
        }

        break;
    case EventKeyboard::KeyCode::KEY_A:
    case EventKeyboard::KeyCode::KEY_LEFT_ARROW:
        DirX += 4.0f;
        break;
    case EventKeyboard::KeyCode::KEY_S:
    case EventKeyboard::KeyCode::KEY_DOWN_ARROW:
        DirY += 4.0f;
        break;
    case EventKeyboard::KeyCode::KEY_D:
    case EventKeyboard::KeyCode::KEY_RIGHT_ARROW:
        DirX -= 4.0f;
        break;
    }
};

this->_eventDispatcher->addEventListenerWithSceneGraphPriority(keyboardListener, this);

//call on update function 
this->scheduleUpdate();

return true;
}


//every frame this function works
void Level1::update(float dt) {

    float newPosX = ::Knight->getPositionX() + (DirX);
    float newPosY = ::Knight->getPositionY() + (DirY);

    ::Knight->setPosition(newPosX, newPosY);
    ::Knight->setRotation(0);
}

//check for player and objectif colliding
bool Level1::ContactBegin(cocos2d::PhysicsContact& contact) {

    PhysicsBody* a = contact.getShapeA()->getBody();
    PhysicsBody* b = contact.getShapeB()->getBody();

    if ((1 == a->getCollisionBitmask() && 2 == b->getCollisionBitmask()) || 2 == a->getCollisionBitmask() && 1 == b->getCollisionBitmask()) 
    {
        auto Next12 = Transition12::create();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, Next12, Color3B(0, 255, 255)));
    }

    if ((1 == a->getCollisionBitmask() && 3 == b->getCollisionBitmask()) || 3 == a->getCollisionBitmask() && 1 == b->getCollisionBitmask())
    {
        jump_condition = true;
    }

    return true;
}
